MANGAL HOUSE — готовый сайт

Файлы:
- index.html — главная
- menu.html — меню и корзина
- contacts.html — контакты
- style.css — дизайн
- script.js — меню, поиск, корзина и заказ

Как загрузить в GitHub:
1. Откройте репозиторий.
2. Add file → Upload files.
3. Перетащите ВСЕ 5 файлов из этой папки.
4. Нажмите Commit changes.
5. Settings → Pages.
6. Source: Deploy from a branch.
7. Branch: main / root → Save.

Важно:
- В contacts.html замените адрес и телефон.
- Сейчас заказ открывается в Telegram как готовое сообщение.
- Цены для позиций, которые ранее не были указаны, можно изменить в script.js.
